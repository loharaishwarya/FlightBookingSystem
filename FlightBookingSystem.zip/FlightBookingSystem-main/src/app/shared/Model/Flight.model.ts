
export class Flight{

    FBS_Flight_Id !: number;
    FBS_Flight_Origin !: string;
    FBS_Flight_Destination !: string;                             
    FBS_Flight_DateTime !: Date;
    FBS_Flight_Fare!: number;


}