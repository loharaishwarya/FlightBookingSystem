import { DestinationPipe } from './destination.pipe';

describe('DestinationPipe', () => {
  it('create an instance', () => {
    const pipe = new DestinationPipe();
    expect(pipe).toBeTruthy();
  });
});
